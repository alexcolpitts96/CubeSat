/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "MK22F51212.h"


void LPTMR0_enable(int miliseconds)
{
	//call this function when low power is needed. This function will activate the LPTMR and its interrupt. The
	// board will go to sleep for "miliseconds" and then will wake up using the lptmr interrupt


	//Disable RTC to allow lower power consumption
//	SIM->SCGC6 |=SIM_SCGC6_RTC_MASK;          // enable clock to RTC
//	RTC->TSR = 0x00;                         // dummy write to RTC TSR
//	SIM->SCGC6 &= ~SIM_SCGC6_RTC_MASK;      // disable clock to RTC


	SIM_SCGC5 |= SIM_SCGC5_LPTMR_MASK; //enable system clock
    //Reset LPTMR module
    LPTMR0_CSR=0x00;
    LPTMR0_PSR=0x00;
    LPTMR0_CMR=0x00;

    // Enable LPT Interrupt in NVIC
    NVIC_EnableIRQ(LPTMR0_IRQn);

	SIM_SOPT1|=0xC0000;  // setting 1khz internal clock to LPTMR
    LPTMR0_CMR=LPTMR_CMR_COMPARE(miliseconds);  //Set compare value
	LPTMR0_PSR|=0x45;  //Prescaler Register, Prescale disabled, 1 count = 1 milisecond
    LPTMR0_CSR=LPTMR_CSR_TIE_MASK;  //Enable interrupt
    LPTMR0_CSR|=LPTMR_CSR_TEN_MASK; //Turn on LPTMR and start counting

    // Enable Low Power Mode
    	SCB->SCR|= SCB_SCR_SLEEPDEEP_Msk; //Enable Sleepdeep instead of sleep
    	//__WFI();   // Wait for interrupt

}

void LPTMR0_IRQHandler(void)
{
   LPTMR0_CSR |= LPTMR_CSR_TCF_MASK; // set the TCF flag to 0
   LPTMR0_CSR&=0xFE; //disable the counter

   // This is to show if the interrupt works
	for(int i = 0;i<100;i++){
		Wait32();
    	putty_putstr("\033[2J\033[1;1H The interrupt works");
    }
}

int main(void)
{
	UART1_putty_init();
	LPTMR0_enable(10000); // wait 10000 seconds

	//wait for interrupt
    while(1){

    	Wait32();

    	//print lptmr value	if timer is running
    	LPTMR0_CNR=1; //you must write a value to counter for syncing
    	if(LPTMR0_CNR>0){
		char buf[30];
		sprintf(buf, "\033[2J\033[1;1H count: %d ",(LPTMR0_CNR));
		putty_putstr(buf);}

    	//only print this when timer is disabled
    	else{putty_putstr("\033[2J\033[1;1H Timer is now disabled and program resumes as normal ");}
    }

    return 0;
}



//putty test code
/////////////////////////////////////////////////////////////////

void UART1_putty_init() {
	uint16_t temp;
	uint16_t ubd;

	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK; // enable clock to PORTE
	SIM_SCGC4 |= SIM_SCGC4_UART1_MASK; // enable clock to UART1

	PORTE_PCR1 |= PORT_PCR_MUX(3);
	PORTE_PCR0 |= PORT_PCR_MUX(3); // configure bits to be UART1

	UART1_C2 &= ~(UART_C2_TE_MASK | UART_C2_RE_MASK); // disable receive/transfer

	UART1_C1 = 0; // set 8 bits

	// calculate and set the baud rate
	ubd = ((21000 * 1000) / (115200 * 16)); // set baudrate
	temp = UART1_BDH & ~(UART_BDH_SBR(0x1F)); // save existing values in register
	UART1_BDH = temp | ((ubd >> 8) & 0x1F);
	UART1_BDL = ubd & UART_BDL_SBR_MASK;

	UART1_C2 |= (UART_C2_TE_MASK | UART_C2_RE_MASK); // enable receive/transfer
}

//Sends a character to PuTTY interface
void putty_putchar(char c) {
	while (!(UART1_S1 & 0x80))
		; // check if the transmit buffer is full, do nothing if so
	UART1_D = c; // if not, write 8 bits to the UART0 data register
	return;
}

//Waits for a character from the PuTTY interface
char putty_getchar(void) {
	while (!(UART1_S1 & 0x20))
		; // check if the receive buffer is empty, do nothing if so
	return UART1_D; // returns the gotten char
}

//Sends a NUL-terminated string to the PuTTY interface
void putty_putstr(char *str) {
	int n = 0;
	while (str[n]) { // is the character a NULL?
		putty_putchar(str[n]); // if not, use putChar to output it
		n++;
	}
	return; // quit when we hit a NULL
}


void Wait32() {
	for(int i = 0;i<15000;i++){
				__asm__("nop");
			}
	return;
}
